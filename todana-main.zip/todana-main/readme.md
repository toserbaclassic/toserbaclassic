# TODANA

TODANA merupakan script yang bisa digunakan sebagai Toko Online Sederhana.

Script ini dibangun dengan menggunakan:

- HTML
- Bootstrap CSS Framework
- Javascript

Di dalam project terdapat folder images, berisikan produk-produk yang akan digunakan untuk menampilkan data.

Link tutorial Youtube: https://www.youtube.com/watch?v=kK23OXSJYQw&t=210s
